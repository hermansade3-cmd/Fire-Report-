# OFFLINE INCIDENT & RESCUE REPORT

Offline-first incident and rescue reporting application.
**Created by Herman Sade**

## Vipengele Vipya: SHARE & EXPORT (kwa Kiswahili)

Baada ya kujaza na kuhifadhi ripoti, fungua ripoti yoyote na uende
**REPORT ACTIONS** (kitufe "Preview" kwenye Dashboard, au fungua ripoti
kisha "Preview Report" kwenye hatua ya mwisho). Hapo utaona:

- 🟢 **Tuma kupitia WhatsApp (Haraka)** — kitufe kikubwa cha kijani
  juu ya ukurasa, ndicho njia ya haraka zaidi ya kutuma ripoti.
- 👁️ **View Report** — inaonyesha ripoti kamili kwa muundo wa taarifa
  rasmi ("JAMBO AFANDE...").
- ✏️ **Edit Report** — rudi kwenye fomu kuendelea kujaza/kurekebisha.
- 📄 **Export PDF** — inatengeneza faili halisi la PDF (offline kabisa,
  hakuna maktaba ya nje/CDN) na kulipakua kwenye kifaa.
- 🖨️ **Print Report** — inafungua "Print" ya kivinjari (Save as PDF pia
  inawezekana humo, ikiwa na picha).
- 📤 **Share Report** — inafungua menyu ya SHARE / EXPORT: Share (native
  share sheet ya simu), WhatsApp, Export PDF, Print, Copy Text, Download
  File, Email, Bluetooth/Quick Share, Save to Drive. Unaweza kuchagua
  kutuma **Ripoti Kamili** au **Muhtasari Tu**.
- 📋 **Copy Report** — inanakili (copy) ripoti nzima kwa muundo wa
  maandishi wa "JAMBO AFANDE" moja kwa moja kwenye clipboard.
- 📁 **Save/Download** — inapakua ripoti kama PDF kwenye kifaa.
- 🗄️ **Archive / 🗑️ Delete** — kama awali; Delete huhamishia ripoti
  kwenye Trash (hairudi kufutwa moja kwa moja).

**Copy, PDF, na Share zote zinatumia muundo mmoja** (barua rasmi ya
"JAMBO AFANDE...") ili chochote unachonakili, kupakua, au kutuma
kiwe sawa na kile unachokiona kwenye "View Report". Data halisi
iliyojazwa kwenye fomu ndiyo inayotumika — hakuna taarifa
inayobuniwa; sehemu ambazo hazikujazwa zinaonyeshwa kama "-".

**Kila kitu kinafanya kazi bila internet**, kwa sababu:
- PDF inatengenezwa moja kwa moja kifaani na `js/pdf-lite.js` (maandishi
  ya msingi ya PDF, bila maktaba ya nje).
- Copy inatumia Clipboard API ya kivinjari.
- Share inatumia Web Share API ya Android/kivinjari (system share
  sheet) — app haiwezi "kulazimisha" WhatsApp/Drive/Bluetooth moja kwa
  moja; badala yake, inafungua orodha ya kushirikisha ya simu yako na
  wewe unachagua unachotaka kutumia, kama ilivyoombwa.
- Kama Web Share API haipatikani kwenye kivinjari chako, app
  inarudi (fallback) kwenye Copy Text au kupakua faili moja kwa moja.

Baada ya kila "Export"/"Share", utaona dirisha dogo la uthibitisho
**"✅ Report tayari kushirikiwa"** lenye Report ID na vitufe vya
"Share Tena", "Fungua PDF", "Print", na "Nimemaliza".

A Progressive Web App (PWA) for fire & rescue crews to fill in complete
incident reports while in the field, with **zero internet connection**
required after the first load. All data is stored locally on the device
using IndexedDB. No CDN, no external libraries, no analytics, no trackers,
no server calls of any kind.

---

## 1. How to run

You need to open `index.html` through a local web server (not by
double‑clicking the file), because Service Workers and some storage
features require `http://` or `https://`, not `file://`.

**Option A — quickest, on a computer with Python installed:**
```bash
cd incident-rescue-app
python3 -m http.server 8080
```
Then open `http://localhost:8080/index.html` in Chrome.

**Option B — any static file server** (e.g. `npx serve`, VS Code "Live
Server" extension, or uploading the folder to any basic static web host)
works identically — the app needs nothing beyond static file hosting.

**On Android:** the simplest path is to host the folder once (even
temporarily, e.g. via a local server on the same phone using an app like
Termux, or by hosting it once online) to install it as a PWA, or copy it
into an app such as a local static server app. Once the PWA is installed
via "Add to Home Screen" the app runs fully offline afterwards.

## 2. How to install as a PWA

1. Open the app's URL in Chrome (Android) or Safari (iPhone).
2. Chrome: tap the menu (⋮) → **"Install app"** / **"Add to Home
   screen"**. Safari: tap Share → **"Add to Home Screen"**.
3. The app icon appears on the home screen and opens full-screen, like a
   native app, with no browser address bar.
4. From then on it opens **instantly, offline**, because the service
   worker has cached the app shell (HTML/CSS/JS/icons).

## 3. How offline mode works

- On first successful load, `service-worker.js` caches every core file
  (HTML, CSS, JS, manifest, icons) into the browser's Cache Storage.
- Every later visit is served from that cache first — no network request
  is required for the app to open and run.
- All report data (text fields, casualties, witnesses, vehicles, crew,
  photos, settings, trash, audit history) is stored in **IndexedDB**,
  which is entirely local to the device and works with no network at
  all, online or offline.
- Nothing is ever sent to a server. There is no backend. The app never
  makes an outbound network request for its own operation.

## 4. How data is stored (technical overview)

IndexedDB database `rescueReportDB` with these object stores:

| Store        | Purpose                                                        |
|--------------|------------------------------------------------------------------|
| `reports`    | Every active report (draft / in progress / completed / archived). Casualties, witnesses, vehicles, crew, fuel entries, and other repeatable sections are embedded arrays *inside* each report document — they always change together with the report, so this keeps every save atomic and avoids partial-write states. |
| `trash`      | Reports the user deleted. Never auto-purged.                     |
| `photos`     | Photo blobs, keyed by `photoId`, linked to a report by `incidentId`. Kept in a separate store from `reports` so large binary data never blocks the (frequent) auto-save of text fields. |
| `settings`   | Station defaults, theme, auto-save interval, app-lock PIN, etc.  |
| `auditLogs`  | Created / updated / completed / archived / restored / deleted history per report. |

**Auto-save:** every field write debounces (default 600ms, configurable
in Settings) and then writes the *entire* current report object back to
IndexedDB. The app also force-flushes any pending save on tab
hide/close (`visibilitychange`, `pagehide`, `beforeunload`), so closing
the app, locking the phone, or losing power right after typing does not
lose the last edit in ordinary use. Report status starts at `DRAFT` and
moves to `IN_PROGRESS` automatically once the user leaves Step 1.

**Nothing is ever deleted automatically.** "Delete" always moves a
report to Trash first; a Trash entry requires an explicit second
confirmation before permanent deletion. Archiving does not delete
anything either — it only changes status and keeps the report fully
viewable and exportable.

## 5. How to back up

Go to **Dashboard → Export/Backup**, then **"Export Full Backup
(JSON)"**. This downloads a single `.json` file containing every report,
every photo (base64-safe blob reference), and your settings. Move this
file to another phone (Bluetooth, USB, WhatsApp file share, SD card —
anything that copies a file) to transfer your data.

## 6. How to restore

Go to **Dashboard → Export/Backup → Import Backup**, choose the `.json`
file. You will be asked how to handle anything that already exists on
the device:
- **Keep existing** — skip anything already on this device.
- **Replace** — overwrite the existing copy with the imported one.
- **Create copy** — keep both, importing the incoming report as a new
  entry.

Importing never deletes anything already on the device.

## 7. How to export a finished report

Open a report → **Preview** (or Dashboard → open a report → Preview),
then:
- **Export/Print PDF** — opens the browser's print dialog on a clean,
  formatted document; choose "Save as PDF" as the destination.
- **JSON** — a single-report backup file.
- **HTML** — a standalone, self-contained formatted report page you can
  open in any browser.

CSV export (Dashboard → Export/Backup → "Export Ripoti Zote (CSV)")
exports a one-row-per-report summary spreadsheet across all reports.

## 8. How to clear data safely

There is deliberately **no "delete everything" button** in the app,
to protect against accidental data loss. To fully reset a device:
1. First export a full backup (Section 5) if you want to keep anything.
2. Then use the browser's own site data controls (e.g. Chrome →
   Settings → Site settings → find this site → "Clear & reset") to wipe
   the IndexedDB database and cache.

Deleting individual reports always goes through the Trash flow inside
the app (Section 4), which is reversible until you choose "Futa Kabisa"
(Permanently Delete) and confirm a second time.

## 9. Browser compatibility

Built and tested against a recent Chromium engine. Expected to work on:
- Chrome / Edge for Android (recommended for installing as a PWA)
- Safari on iOS 16.4+ (Add to Home Screen; note iOS enforces stricter
  storage eviction rules for installed web apps than Android does —
  back up regularly)
- Any recent desktop Chromium/Firefox browser for administrative use

Requires: IndexedDB, Service Workers, `getUserMedia`/file input camera
capture, and `navigator.geolocation` (GPS capture is optional — the app
works fully without GPS or location permission).

## 10. App Lock

Settings → "Enable App Lock" sets a 4-digit local PIN that gates the
app on open. This is **basic local privacy protection only** — it is
not encryption, and does not protect the underlying IndexedDB data from
someone with direct device/file-system access. It exists to stop casual
over-the-shoulder access to sensitive incident data (e.g. casualty
names), not to defend against a determined attacker with the device in
hand.

## 11. Project structure

```
incident-rescue-app/
  index.html            App shell / entry point
  manifest.json          PWA manifest
  service-worker.js      Offline cache-first service worker
  offline.html            Fallback page for an uncached first-ever offline visit
  css/style.css           All styling (dark-mode capable, mobile-first)
  js/db.js                IndexedDB persistence layer (RescueDB)
  js/app.js               App logic: routing, forms, auto-save, all screens
  js/pdf-lite.js           Dependency-free local PDF generator (no CDN)
  js/export.js            Narrative template, PDF/Copy/Share/WhatsApp/Email, CSV/JSON
  icons/                   App icons (192/512, incl. maskable variants)
  README.md               This file
```

No build step. No `node_modules`. No bundler. Every file is used as-is.

## 12. What has actually been tested

This build was tested with an automated browser (Chromium via
Playwright) driving the real app against a local static file server,
covering: creating a report and auto-saving field-by-field; a hard page
reload mid-form confirming no data loss and that the form resumes on
the same step; adding multiple casualties, a witness, a vehicle, and a
photo, then reloading and confirming all of it persisted; completing a
report and generating the Preview document; moving a report to Trash
and restoring it; archiving a report; capturing GPS coordinates;
exporting CSV and a full JSON backup and re-importing it in "create
copy" mode; search; statistics; setting and validating an App Lock PIN;
and confirming the app shell (HTML/CSS/JS/icons) is precached by the
service worker and that the app still renders with the network fully
disabled.

A second automated pass specifically exercised the new Share/Export
system: filling a full report and opening Report Actions; Copy Report
verified byte-for-byte against the clipboard; Export PDF verified as a
real, valid, multi-page PDF file (parsed and its text content checked
with an independent PDF library, including Swahili text and pagination
across 3 pages for a longer report); opening the generated PDF from
the confirmation dialog; the Share sheet's "Muhtasari Tu" (Summary)
mode verified to produce the short WhatsApp-style summary format
(and confirmed it does **not** leak the full narrative); the WhatsApp
quick button verified to open a correctly `wa.me`-encoded link with
the real report text; and Print Report verified to invoke the
browser's print function without errors. The report's data was
re-checked after all of this and confirmed intact.

No console or page errors were observed in any of these runs. Manual
testing on an actual Android phone (camera capture UI, the real Android
share sheet with WhatsApp/Drive/Bluetooth installed, installed-PWA
behavior, real GPS hardware, and iOS Safari's storage rules) has
**not** been done and is recommended before relying on this for live
operations — please test thoroughly on your own device(s) first.

---
Created by Herman Sade


## 5. Delete & Trash

- Shikilia kadi ya ripoti kwa takriban sekunde 1.
- Programu itaomba uthibitisho wa Delete na Password.
- Ukithibitisha, ripoti itaondoka kwenye Reports na kuingia **Trash**.
- Data haifutwi kabisa; unaweza kwenda **Trash → Restore**.
- **Futa Kabisa** ndani ya Trash inahitaji Password tena na huondoa ripoti pamoja na picha zake.
- Trash haihusishwi tena na purge ya kuanzisha app; hivyo ripoti zilizofutwa hubaki salama hadi mtumiaji achague kuziondoa kabisa.
