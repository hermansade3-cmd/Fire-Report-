/* pdf-lite.js — Kizio (module) cha kutengeneza PDF bila maktaba yoyote ya nje,
 * bila CDN, na bila internet. Kinatumia herufi za msingi za PDF (Helvetica,
 * fonti ya kawaida inayojumuishwa kwenye kila kisomaji cha PDF) kuandika
 * hati ya maandishi (text) yenye kurasa nyingi (A4), vichwa vya habari na
 * footer kwenye kila ukurasa.
 *
 * Haihitaji internet wala server — inatengeneza Blob ya PDF moja kwa moja
 * kwenye kifaa (browser).
 */
(function () {
"use strict";

const PAGE_W = 595.28; // A4 pt
const PAGE_H = 841.89;
const MARGIN = 46;
const FONT_SIZE = 10;
const LINE_HEIGHT = 13.6;
const HEADER_H = 46;
const FOOTER_H = 30;

function toWinAnsi(str) {
  // Msingi wa Helvetica hauna Unicode kamili; badilisha herufi zisizo za
  // Kilatini na alama za kawaida (WinAnsi inashughulikia Kiswahili vizuri
  // kwa sababu haitumii alama maalum nje ya alfabeti ya Kilatini).
  let out = "";
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i);
    out += code < 256 ? str[i] : "?";
  }
  return out;
}

function escapePdfString(s) {
  return s.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

// Kadiria upana wa herufi kwa Helvetica (wastani) ili tuvunje mistari vizuri
// bila kuhitaji font-metrics kamili.
function wrapLine(line, maxChars) {
  if (line.length <= maxChars) return [line];
  const words = line.split(" ");
  const out = [];
  let cur = "";
  for (const w of words) {
    const candidate = cur ? cur + " " + w : w;
    if (candidate.length > maxChars) {
      if (cur) out.push(cur);
      // neno refu kuliko mstari mzima: likate kwa nguvu
      if (w.length > maxChars) {
        let rest = w;
        while (rest.length > maxChars) {
          out.push(rest.slice(0, maxChars));
          rest = rest.slice(maxChars);
        }
        cur = rest;
      } else {
        cur = w;
      }
    } else {
      cur = candidate;
    }
  }
  if (cur) out.push(cur);
  return out;
}

function buildLines(bodyText) {
  const maxChars = Math.floor((PAGE_W - 2 * MARGIN) / (FONT_SIZE * 0.52));
  const rawLines = bodyText.split("\n");
  const lines = [];
  rawLines.forEach((rl) => {
    if (rl.trim() === "") { lines.push(""); return; }
    wrapLine(rl, maxChars).forEach((l) => lines.push(l));
  });
  return lines;
}

function paginate(lines) {
  const usableH = PAGE_H - MARGIN - HEADER_H - FOOTER_H - MARGIN;
  const linesPerPage = Math.max(10, Math.floor(usableH / LINE_HEIGHT));
  const pages = [];
  for (let i = 0; i < lines.length; i += linesPerPage) {
    pages.push(lines.slice(i, i + linesPerPage));
  }
  if (!pages.length) pages.push([]);
  return pages;
}

function buildContentStream(pageLines, headerText, footerLeft, footerRight) {
  let ops = [];
  ops.push("BT");
  ops.push("/F2 12 Tf");
  ops.push(`${MARGIN} ${PAGE_H - MARGIN - 14} Td`);
  ops.push(`(${escapePdfString(toWinAnsi(headerText))}) Tj`);
  ops.push("ET");

  // mstari mdogo chini ya kichwa
  const lineY = PAGE_H - MARGIN - HEADER_H + 8;
  ops.push(`${MARGIN} ${lineY} m ${PAGE_W - MARGIN} ${lineY} l S`);

  ops.push("BT");
  ops.push(`/F1 ${FONT_SIZE} Tf`);
  ops.push(`${LINE_HEIGHT} TL`);
  ops.push(`${MARGIN} ${PAGE_H - MARGIN - HEADER_H - 6} Td`);
  pageLines.forEach((line) => {
    ops.push(`(${escapePdfString(toWinAnsi(line))}) Tj`);
    ops.push("T*");
  });
  ops.push("ET");

  ops.push("BT");
  ops.push("/F1 8 Tf");
  ops.push(`${MARGIN} ${MARGIN - 14} Td`);
  ops.push(`(${escapePdfString(toWinAnsi(footerLeft))}) Tj`);
  ops.push("ET");
  ops.push("BT");
  ops.push("/F1 8 Tf");
  ops.push(`${PAGE_W - MARGIN - footerRight.length * 4.2} ${MARGIN - 14} Td`);
  ops.push(`(${escapePdfString(toWinAnsi(footerRight))}) Tj`);
  ops.push("ET");

  return ops.join("\n");
}

/**
 * Tengeneza PDF (Uint8Array) kutoka kwenye maandishi ya kawaida (plain text).
 * opts: { headerText, bodyText, footerLeftPrefix }
 */
function generate(opts) {
  const headerText = opts.headerText || "";
  const bodyText = opts.bodyText || "";
  const footerLeftPrefix = opts.footerLeftPrefix || "Created by Herman Sade";

  const lines = buildLines(bodyText);
  const pages = paginate(lines);
  const totalPages = pages.length;

  const objects = []; // { num, body } — tutajaza num baadaye
  // 1: Catalog, 2: Pages — tutaziweka mwishoni baada ya kujua idadi ya kurasa
  const pageObjNums = [];
  const contentObjNums = [];
  const fontRegularNum = 3 + totalPages * 2;
  const fontBoldNum = fontRegularNum + 1;

  let nextNum = 3;
  const pageEntries = [];
  pages.forEach((pageLines, idx) => {
    const pageNum = nextNum++;
    const contentNum = nextNum++;
    pageObjNums.push(pageNum);
    contentObjNums.push(contentNum);
    const footerRight = `Ukurasa ${idx + 1}/${totalPages}`;
    const stream = buildContentStream(pageLines, headerText, footerLeftPrefix, footerRight);
    pageEntries.push({ pageNum, contentNum, stream });
  });

  const objStrings = [];
  objStrings[1] = `1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n`;
  objStrings[2] = `2 0 obj\n<< /Type /Pages /Kids [${pageObjNums.map((n) => n + " 0 R").join(" ")}] /Count ${totalPages} >>\nendobj\n`;

  pageEntries.forEach(({ pageNum, contentNum }) => {
    objStrings[pageNum] = `${pageNum} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Resources << /Font << /F1 ${fontRegularNum} 0 R /F2 ${fontBoldNum} 0 R >> >> /Contents ${contentNum} 0 R >>\nendobj\n`;
  });
  pageEntries.forEach(({ contentNum, stream }) => {
    const bytesLen = new TextEncoder().encode(stream).length;
    objStrings[contentNum] = `${contentNum} 0 obj\n<< /Length ${bytesLen} >>\nstream\n${stream}\nendstream\nendobj\n`;
  });
  objStrings[fontRegularNum] = `${fontRegularNum} 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj\n`;
  objStrings[fontBoldNum] = `${fontBoldNum} 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>\nendobj\n`;

  const totalObjs = fontBoldNum;

  // Jenga faili kama Uint8Array ukihesabu offsets sahihi kwa byte.
  const encoder = new TextEncoder();
  const chunks = [];
  let offset = 0;
  const header = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
  chunks.push(encoder.encode(header));
  offset += chunks[chunks.length - 1].length;

  const xrefOffsets = new Array(totalObjs + 1).fill(0);
  for (let n = 1; n <= totalObjs; n++) {
    xrefOffsets[n] = offset;
    const bytes = encoder.encode(objStrings[n]);
    chunks.push(bytes);
    offset += bytes.length;
  }

  const xrefStart = offset;
  let xref = `xref\n0 ${totalObjs + 1}\n0000000000 65535 f \n`;
  for (let n = 1; n <= totalObjs; n++) {
    xref += String(xrefOffsets[n]).padStart(10, "0") + " 00000 n \n";
  }
  chunks.push(encoder.encode(xref));

  const trailer = `trailer\n<< /Size ${totalObjs + 1} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF`;
  chunks.push(encoder.encode(trailer));

  let totalLen = 0;
  chunks.forEach((c) => (totalLen += c.length));
  const out = new Uint8Array(totalLen);
  let pos = 0;
  chunks.forEach((c) => { out.set(c, pos); pos += c.length; });
  return out;
}

function generateBlob(opts) {
  const bytes = generate(opts);
  return new Blob([bytes], { type: "application/pdf" });
}

window.PdfLite = { generate, generateBlob };

})();
