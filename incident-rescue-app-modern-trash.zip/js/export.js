/* export.js — Ripoti (report) formatting, PDF, Copy, Share, Backup/Export
 * kwa Offline Incident & Rescue Report. Hakuna maktaba ya nje/CDN — kila
 * kitu kinafanya kazi 100% offline kwenye kifaa.
 */
(function () {
"use strict";

function escapeHtml(s) {
  return (s == null ? "" : String(s)).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
const V = (x) => (x === undefined || x === null || x === "" ? "-" : String(x));

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

function downloadJSON(data, filename) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  downloadBlob(blob, filename);
}

function downloadTextFile(text, filename) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  downloadBlob(blob, filename);
}

function downloadHTML(innerHtml, filename) {
  const full = `<!DOCTYPE html><html lang="sw"><head><meta charset="utf-8"><title>Taarifa ya Tukio</title>
  <style>
    body{font-family:sans-serif;background:#fff;color:#111;padding:26px;font-size:13.5px;line-height:1.6;max-width:720px;margin:0 auto;}
    h2{font-size:16px;text-align:center;margin-bottom:2px;}
    h3{font-size:13px;text-transform:uppercase;border-bottom:1px solid #ccc;padding-bottom:4px;margin:18px 0 8px 0;letter-spacing:.03em;}
    .sub-center{text-align:center;color:#555;font-size:12px;margin-bottom:16px;}
    .narrative-body{white-space:pre-wrap;}
    .photo-grid{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;}
    .photo-grid div{width:120px;}
    .photo-grid img{width:100%;border-radius:4px;border:1px solid #ddd;}
    .footer{text-align:center;color:#999;margin-top:28px;font-size:11px;}
  </style></head><body>${innerHtml}<div class="footer">Incident &amp; Rescue Reporting System<br>Created by Herman Sade</div></body></html>`;
  const blob = new Blob([full], { type: "text/html" });
  downloadBlob(blob, filename);
}

function csvEscape(v) {
  if (v == null) return "";
  const s = String(v).replace(/"/g, '""');
  return /[",\n]/.test(s) ? `"${s}"` : s;
}

function downloadReportsCSV(reports) {
  const headers = [
    "Incident ID", "Report Number", "Status", "Date", "Type", "Region", "District", "Ward",
    "Street", "Response Time", "Scene Duration", "Total Duration", "Casualty Count",
    "Deaths", "Reporter Name", "Reporter Phone", "Created At", "Updated At",
  ];
  const rows = reports.map((r) => [
    r.incidentId, r.reportNumber, r.status, r.incident?.date, r.incident?.type,
    r.location?.region, r.location?.district, r.location?.ward, r.location?.street,
    r.derived?.responseTime, r.derived?.sceneDuration, r.derived?.totalDuration,
    (r.casualties || []).length, (r.fatality?.deceased || []).length,
    r.incident?.reporterName, r.incident?.reporterPhone, r.createdAt, r.updatedAt,
  ]);
  const csv = [headers, ...rows].map((row) => row.map(csvEscape).join(",")).join("\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
  downloadBlob(blob, `rescue-reports-${Date.now()}.csv`);
}

// =================================================================
// TAARIFA KAMILI (muundo wa "JAMBO AFANDE") - inatumika kwa
// Copy Report, Export PDF, Share Report, View Report na Print Report
// =================================================================

function incidentTypeLabel(i) {
  if ((i.type === "Ajali nyingine" || i.type === "Tukio jingine") && i.otherType) return i.otherType;
  return V(i.type);
}

function placeLabel(l) {
  return [l.street, l.ward, l.landmark].filter(Boolean).join(", ") || "-";
}

function buildNarrativeText(r) {
  const i = r.incident || {}, l = r.location || {}, t = r.timeline || {}, d = r.damage || {},
        cz = r.cause || {}, ch = r.challenges || {}, cr = r.crew || {}, f = r.fatality || {};
  const lines = [];
  const P = (s) => lines.push(s);
  const blank = () => lines.push("");

  P("JAMBO AFANDE.");
  blank();
  P(`TAARIFA KAMILI YA TUKIO LA ${incidentTypeLabel(i).toUpperCase()} MKOA WA ${V(l.region).toUpperCase()}, WILAYA YA ${V(l.district).toUpperCase()}, MTAA WA ${V(l.street).toUpperCase()}`);
  blank();
  P(`Leo tarehe ${V(i.date)}, majira ya saa ${V(i.timeReceived)}, kituo cha ${V(cr.station)} tumepokea taarifa kutoka kwa mtoa taarifa ${V(i.reporterName)}, mwenye namba ya simu ${V(i.reporterPhone)}, ametujulisha tukio la ${incidentTypeLabel(i)} lililotokea ${placeLabel(l)}.`);
  blank();

  const v0 = (r.vehiclesInvolved || [])[0];
  if (v0 || cr.driver || cr.shiftLeader) {
    P(`Gari lenye namba ${V(v0 && v0.regNo)} aina ya ${V(v0 && v0.type)}, likiendeshwa na ${V(cr.driver)}, limetoka kituoni na kuelekea eneo la tukio likiongozwa na kiongozi wa zamu ${V(cr.shiftLeader)}.`);
    blank();
  }

  P("TAARIFA ZA KIOFISI");
  blank();
  P(V(r.reportNumber || r.incidentId));
  blank();

  P("TAARIFA ZA ENEO/ANUANI");
  blank();
  P(`Mtaa: ${V(l.street)}`);
  P(`Kata: ${V(l.ward)}`);
  P(`Wilaya: ${V(l.district)}`);
  P(`Mkoa: ${V(l.region)}`);
  P(`Barabara: ${V(l.road)}`);
  P(`Alama ya eneo: ${V(l.landmark)}`);
  P(`Maelezo ya eneo: ${V(l.description)}`);
  if (l.gps && l.gps.lat) P(`GPS: ${l.gps.lat}, ${l.gps.lng} (usahihi +-${l.gps.accuracy}m)`);
  blank();

  P("TAARIFA ZA MUDA");
  blank();
  P(`Kupokea taarifa saa ${V(t.timeReceived)}`);
  P(`Kuondoka kituoni saa ${V(t.timeDeparted)}`);
  P(`Kufika eneo la tukio saa ${V(t.timeArrived)}`);
  P(`Kuanza kazi saa ${V(t.timeOpStart)}`);
  P(`Kumaliza kazi saa ${V(t.timeOpEnd)}`);
  P(`Kuondoka eneo la tukio saa ${V(t.timeDepartedScene)}`);
  P(`Kufika kituoni saa ${V(t.timeReturned)}`);
  if (r.derived) {
    P(`Muda wa kuwahi (response time): ${V(r.derived.responseTime)}`);
    P(`Muda uliotumika eneo la tukio: ${V(r.derived.sceneDuration)}`);
    P(`Muda wote wa operesheni: ${V(r.derived.totalDuration)}`);
  }
  blank();

  P("HATUA ZILIZOCHUKULIWA NA JESHI LA ZIMAMOTO NA UOKOAJI");
  blank();
  P(V(r.actionsTaken && r.actionsTaken.text));
  const checklistOn = Object.entries((r.actionsTaken && r.actionsTaken.checklist) || {}).filter(([, on]) => on).map(([k]) => k);
  if (checklistOn.length) { blank(); P(`Hatua nyingine zilizoainishwa: ${checklistOn.join(", ")}`); }
  blank();

  P("CHANZO CHA TUKIO");
  blank();
  P(V((cz.options || []).join(", ")));
  blank();
  P(`Maelezo ya ziada: ${V(cz.detail)}`);
  blank();

  P("TAARIFA ZA ENEO LA TUKIO");
  blank();
  P(V(l.description));
  blank();

  P("MAGARI/VITU VILIVYOHUSIKA");
  blank();
  if ((r.vehiclesInvolved || []).length) {
    r.vehiclesInvolved.forEach((v, idx) => {
      P(`${idx + 1}. ${V(v.type)} - ${V(v.regNo)} - ${V(v.makeModel)} - ${V(v.color)}`);
      P(`   Mmiliki: ${V(v.owner)}`);
      P(`   Maelezo: ${V(v.notes)}`);
    });
  } else {
    P("Hakuna gari/kitu kilichorekodiwa.");
  }
  blank();

  P("TAARIFA ZA MAJERUHI");
  blank();
  P(`Jumla ya majeruhi: ${(r.casualties || []).length}`);
  blank();
  if ((r.casualties || []).length) {
    r.casualties.forEach((c, idx) => {
      P(`${idx + 1}. Jina: ${V(c.name)}`);
      P(`   Umri: ${V(c.age)}`);
      P(`   Jinsia: ${V(c.sex)}`);
      P(`   Hali: ${V(c.condition)}`);
      P(`   Aina ya jeraha: ${V(c.injury)}`);
      P(`   Huduma ya kwanza: ${V(c.firstAid)}`);
      P(`   Hospitali/Kituo: ${V(c.hospital)}`);
      P(`   Usafiri: ${V(c.transport)}`);
      P(`   Maelezo: ${V(c.notes)}`);
    });
  } else {
    P("Hakuna majeruhi walioripotiwa.");
  }
  blank();

  P("KIFO");
  blank();
  if (f.occurred && (f.deceased || []).length) {
    P("KIFO KIMETOKEA");
    blank();
    P(`Jumla ya waliofariki: ${f.deceased.length}`);
    blank();
    f.deceased.forEach((p, idx) => {
      P(`${idx + 1}. Jina: ${V(p.name)}`);
      P(`   Umri: ${V(p.age)}`);
      P(`   Jinsia: ${V(p.sex)}`);
      P(`   Maelezo/Status: ${V(p.status)}`);
      P(`   Maelezo mengine: ${V(p.notes)}`);
    });
  } else {
    P("HAKUNA");
  }
  blank();

  P("HASARA ILIYOTOKEA");
  blank();
  const damageParts = [d.propertyDamaged, d.vehicleDamage, d.equipmentDamage, d.otherLosses].filter(Boolean);
  P(V(d.description || damageParts.join("; ")));
  blank();
  P(`Makadirio ya hasara: TZS ${V(d.estimatedLoss)}`);
  blank();

  P("GHARAMA ZILIZOTUMIWA NA JESHI KATIKA TUKIO HILO");
  blank();
  if ((r.fuel || []).length) {
    r.fuel.forEach((fl) => { P(`Mafuta: ${V(fl.fuelType)} - LT ${V(fl.litres)} (${V(fl.regNo)})`); if (fl.otherResources) P(`Rasilimali nyingine: ${fl.otherResources}`); });
  } else {
    P("Mafuta: -");
    P("Rasilimali nyingine: -");
  }
  blank();

  P("UMBALI WA KWENDA NA KURUDI ENEO LA TUKIO");
  blank();
  P("KM -  (haijarekodiwa kwenye fomu)");
  blank();

  P("VIKOSI/TAASISI NYINGINE VILIVYOSHIRIKI");
  blank();
  const teamChecks = (r.otherTeams && r.otherTeams.checks) || [];
  if (teamChecks.length && !(teamChecks.length === 1 && teamChecks[0] === "None")) {
    P(teamChecks.join(", "));
  } else {
    P("Hakuna kikosi kingine kilichoshiriki.");
  }
  ((r.otherTeams && r.otherTeams.entries) || []).forEach((e) => {
    P(`${V(e.name)}`);
    P(`Jukumu: ${V(e.role)}`);
    if (e.notes) P(`Maelezo: ${e.notes}`);
  });
  blank();

  P("SHAHIDI/MAELEZO YA MASHUHUDA");
  blank();
  if ((r.witnesses || []).length) {
    r.witnesses.forEach((w) => {
      P(`${V(w.name)} - ${V(w.phone)}`);
      P(`Maelezo: ${V(w.statement)}`);
    });
  } else {
    P("Hakuna shahidi aliyerekodiwa.");
  }
  blank();

  P("CHANGAMOTO");
  blank();
  const chOpts = (ch.options || []).filter((o) => o !== "None");
  if (chOpts.length || ch.text) {
    if (chOpts.length) P(chOpts.join(", "));
    if (ch.text) P(V(ch.text));
  } else {
    P("HAKUNA");
  }
  blank();

  P("PICHA ZA TUKIO");
  blank();
  if ((r.photoIds || []).length) {
    r.photoIds.forEach((id, idx) => P(`Picha ${idx + 1}: (ameambatanishwa - angalia PDF/HTML kwa picha halisi)`));
  } else {
    P("Hakuna picha zilizoambatanishwa.");
  }
  blank();

  P("TAARIFA ZA ASKARI/CREW");
  blank();
  P(`Kiongozi wa zamu: ${V(cr.shiftLeader)}`);
  P(`Dereva: ${V(cr.driver)}`);
  const members = (cr.members || []).map((m) => `${V(m.name)} (${V(m.role)})`).join(", ");
  P(`Askari/Crew: ${members || "-"}`);
  blank();

  P("Naomba kuwasilisha Afande,");
  blank();
  P(V(cr.shiftLeader));
  P(`${V(cr.station)}`);
  blank();
  P("Created by Herman Sade");

  return lines.join("\n");
}

// Muhtasari mfupi (kwa WhatsApp/Share Summary Only)
function buildSummaryText(r) {
  const i = r.incident || {}, l = r.location || {};
  const worstCondition = (r.casualties || []).reduce((worst, c) => {
    const order = ["Unknown", "Stable", "Serious", "Critical", "Unconscious"];
    if (!c.condition) return worst;
    return order.indexOf(c.condition) > order.indexOf(worst) ? c.condition : worst;
  }, "");
  const actions = (r.actionsTaken && r.actionsTaken.text) || "";
  const lines = [
    "INCIDENT & RESCUE REPORT",
    "",
    `Report ID: ${V(r.reportNumber || r.incidentId)}`,
    `Date: ${V(i.date)}`,
    `Time: ${V(i.timeReceived)}`,
    `Location: ${placeLabel(l)}, ${V(l.district)}, ${V(l.region)}`,
    `Incident Type: ${incidentTypeLabel(i)}`,
    `Severity: ${V(worstCondition)}`,
    `Persons Involved: ${(r.casualties || []).length + (r.witnesses || []).length}`,
    `Casualties: ${(r.casualties || []).length}`,
    `Rescue Actions: ${V(actions).slice(0, 160)}`,
    `Resources Used: ${(r.fuel || []).map((f) => `${V(f.fuelType)} ${V(f.litres)}L`).join(", ") || "-"}`,
    `Current Status: ${V(r.status)}`,
    `Additional Notes: ${V(r.challenges && r.challenges.text)}`,
    "",
    "Created by: Herman Sade",
    "App: Incident & Rescue Reporting",
  ];
  return lines.join("\n");
}

function buildNarrativeHtml(r, photos) {
  const text = buildNarrativeText(r);
  let html = `<div class="narrative-body">${escapeHtml(text)}</div>`;
  if (photos && photos.length) {
    html += `<h3>Picha za Tukio (Attachments)</h3><div class="photo-grid">`;
    photos.forEach((p, idx) => {
      const url = URL.createObjectURL(p.blob);
      html += `<div><img src="${url}"><div style="font-size:10px;color:#555;">Picha ${idx + 1}${p.caption ? ": " + escapeHtml(p.caption) : ""}</div></div>`;
    });
    html += `</div>`;
  }
  return html;
}

// =================================================================
// PDF (inatengenezwa moja kwa moja kwenye kifaa - js/pdf-lite.js)
// =================================================================
function generateReportPdfBlob(r) {
  const header = `OFFLINE INCIDENT & RESCUE REPORT - ${r.reportNumber || r.incidentId}`;
  const body = buildNarrativeText(r);
  return window.PdfLite.generateBlob({ headerText: header, bodyText: body, footerLeftPrefix: "Created by Herman Sade" });
}

function downloadReportPdf(r) {
  const blob = generateReportPdfBlob(r);
  downloadBlob(blob, `${r.reportNumber || r.incidentId}.pdf`);
  return blob;
}

// =================================================================
// COPY, SHARE, WHATSAPP, EMAIL
// =================================================================
async function copyText(text) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
    throw new Error("no-clipboard-api");
  } catch (e) {
    // mbadala (fallback) kwa vivinjari vya zamani
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    let ok = false;
    try { ok = document.execCommand("copy"); } catch (e2) { ok = false; }
    ta.remove();
    return ok;
  }
}

function canNativeShare() {
  return typeof navigator.share === "function";
}
function canNativeShareFiles(files) {
  return typeof navigator.canShare === "function" && navigator.canShare({ files });
}

async function shareText(title, text) {
  if (canNativeShare()) {
    try {
      await navigator.share({ title, text });
      return { ok: true, method: "native" };
    } catch (e) {
      if (e && e.name === "AbortError") return { ok: false, method: "native", cancelled: true };
      // itaanguka kwenye fallback hapa chini
    }
  }
  const copied = await copyText(text);
  return { ok: copied, method: "copy-fallback" };
}

async function sharePdfFile(r) {
  const blob = generateReportPdfBlob(r);
  const filename = `${r.reportNumber || r.incidentId}.pdf`;
  const file = new File([blob], filename, { type: "application/pdf" });
  if (canNativeShare() && canNativeShareFiles([file])) {
    try {
      await navigator.share({ title: "Incident & Rescue Report", text: `Ripoti: ${r.reportNumber || r.incidentId}`, files: [file] });
      return { ok: true, method: "native-file" };
    } catch (e) {
      if (e && e.name === "AbortError") return { ok: false, method: "native-file", cancelled: true };
    }
  }
  // Fallback: pakua PDF kisha mwambie mtumiaji aishare mwenyewe
  downloadBlob(blob, filename);
  return { ok: true, method: "download-fallback" };
}

function whatsappShare(text) {
  window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
}

function mailtoShare(subject, text) {
  window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;
}

window.RescueExport = {
  downloadJSON, downloadHTML, downloadTextFile, downloadReportsCSV,
  buildNarrativeText, buildSummaryText, buildNarrativeHtml,
  generateReportPdfBlob, downloadReportPdf,
  copyText, shareText, sharePdfFile, whatsappShare, mailtoShare,
  canNativeShare, canNativeShareFiles,
};

})();
