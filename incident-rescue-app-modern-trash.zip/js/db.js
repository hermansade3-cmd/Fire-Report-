/* db.js
 * IndexedDB persistence layer for the Offline Incident & Rescue Report app.
 * Stores: reports, photos, trash, settings, auditLogs
 * Casualties / witnesses / vehicles / crew / actions / etc. are kept as
 * arrays embedded inside each report document (they are always read/written
 * together with the report, so embedding avoids extra transactions and keeps
 * auto-save atomic). Photos are kept in their own store (binary blobs) keyed
 * by incidentId so large binary data never blocks report auto-save.
 */

const DB_NAME = "rescueReportDB";
const DB_VERSION = 2;

let dbPromise = null;

function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (e) => {
      const db = e.target.result;

      if (!db.objectStoreNames.contains("reports")) {
        const store = db.createObjectStore("reports", { keyPath: "incidentId" });
        store.createIndex("status", "status", { unique: false });
        store.createIndex("createdAt", "createdAt", { unique: false });
        store.createIndex("incidentDate", "incident.date", { unique: false });
        store.createIndex("reportNumber", "reportNumber", { unique: false });
      }

      if (!db.objectStoreNames.contains("trash")) {
        db.createObjectStore("trash", { keyPath: "incidentId" });
      }

      if (!db.objectStoreNames.contains("photos")) {
        const p = db.createObjectStore("photos", { keyPath: "photoId" });
        p.createIndex("incidentId", "incidentId", { unique: false });
      }

      if (!db.objectStoreNames.contains("settings")) {
        db.createObjectStore("settings", { keyPath: "key" });
      }

      if (!db.objectStoreNames.contains("auditLogs")) {
        const a = db.createObjectStore("auditLogs", { keyPath: "id", autoIncrement: true });
        a.createIndex("incidentId", "incidentId", { unique: false });
      }
    };

    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror = (e) => reject(e.target.error);
  });
  return dbPromise;
}

function tx(storeNames, mode = "readonly") {
  return openDB().then((db) => db.transaction(storeNames, mode));
}

function promisifyRequest(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

const RescueDB = {
  // ---------- Reports ----------
  async putReport(report) {
    const t = await tx(["reports"], "readwrite");
    const store = t.objectStore("reports");
    await promisifyRequest(store.put(report));
    return new Promise((res, rej) => {
      t.oncomplete = () => res(report);
      t.onerror = () => rej(t.error);
    });
  },

  async getReport(incidentId) {
    const t = await tx(["reports"]);
    return promisifyRequest(t.objectStore("reports").get(incidentId));
  },

  async getAllReports() {
    const t = await tx(["reports"]);
    return promisifyRequest(t.objectStore("reports").getAll());
  },

  async deleteReportHard(incidentId) {
    const t = await tx(["reports"], "readwrite");
    t.objectStore("reports").delete(incidentId);
    return new Promise((res, rej) => {
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
    });
  },

  // ---------- Trash ----------
  async moveToTrash(report) {
    const t = await tx(["reports", "trash"], "readwrite");
    t.objectStore("reports").delete(report.incidentId);
    report.status = "DELETED";
    report.deletedAt = new Date().toISOString();
    t.objectStore("trash").put(report);
    return new Promise((res, rej) => {
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
    });
  },

  async restoreFromTrash(incidentId, newStatus = "DRAFT") {
    const t = await tx(["reports", "trash"], "readwrite");
    const trashStore = t.objectStore("trash");
    const report = await promisifyRequest(trashStore.get(incidentId));
    if (report) {
      trashStore.delete(incidentId);
      report.status = newStatus;
      delete report.deletedAt;
      t.objectStore("reports").put(report);
    }
    return new Promise((res, rej) => {
      t.oncomplete = () => res(report);
      t.onerror = () => rej(t.error);
    });
  },

  async getAllTrash() {
    const t = await tx(["trash"]);
    return promisifyRequest(t.objectStore("trash").getAll());
  },

  async purgeTrash() {
    const items = await this.getAllTrash();
    for (const r of items) await this.permanentlyDelete(r.incidentId);
  },

  // Permanently remove a trashed report and all of its photos.
  // This is intentionally separate from moveToTrash so normal Delete is reversible.
  async permanentlyDelete(incidentId) {
    const photos = await this.getPhotosForIncident(incidentId);
    const t = await tx(["reports", "trash", "photos"], "readwrite");
    t.objectStore("reports").delete(incidentId);
    t.objectStore("trash").delete(incidentId);
    const photoStore = t.objectStore("photos");
    photos.forEach((p) => photoStore.delete(p.photoId));
    return new Promise((res, rej) => {
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error || new Error("Transaction aborted"));
    });
  },

  // ---------- Photos ----------
  async putPhoto(photo) {
    const t = await tx(["photos"], "readwrite");
    t.objectStore("photos").put(photo);
    return new Promise((res, rej) => {
      t.oncomplete = () => res(photo);
      t.onerror = () => rej(t.error);
    });
  },

  async getPhotosForIncident(incidentId) {
    const t = await tx(["photos"]);
    const idx = t.objectStore("photos").index("incidentId");
    return promisifyRequest(idx.getAll(IDBKeyRange.only(incidentId)));
  },

  async deletePhoto(photoId) {
    const t = await tx(["photos"], "readwrite");
    t.objectStore("photos").delete(photoId);
    return new Promise((res, rej) => {
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
    });
  },

  async getAllPhotos() {
    const t = await tx(["photos"]);
    return promisifyRequest(t.objectStore("photos").getAll());
  },

  // ---------- Settings ----------
  async getSetting(key, fallback = null) {
    const t = await tx(["settings"]);
    const row = await promisifyRequest(t.objectStore("settings").get(key));
    return row ? row.value : fallback;
  },

  async setSetting(key, value) {
    const t = await tx(["settings"], "readwrite");
    t.objectStore("settings").put({ key, value });
    return new Promise((res, rej) => {
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
    });
  },

  async getAllSettings() {
    const t = await tx(["settings"]);
    const rows = await promisifyRequest(t.objectStore("settings").getAll());
    const out = {};
    rows.forEach((r) => (out[r.key] = r.value));
    return out;
  },

  // ---------- Audit ----------
  async logAction(incidentId, action) {
    const t = await tx(["auditLogs"], "readwrite");
    t.objectStore("auditLogs").add({
      incidentId,
      action,
      at: new Date().toISOString(),
    });
    return new Promise((res, rej) => {
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
    });
  },

  async getAuditLog(incidentId) {
    const t = await tx(["auditLogs"]);
    const idx = t.objectStore("auditLogs").index("incidentId");
    return promisifyRequest(idx.getAll(IDBKeyRange.only(incidentId)));
  },

  // ---------- Full backup / restore ----------
  async exportFullBackup() {
    const [reports, trash, photos, settingsRows] = await Promise.all([
      this.getAllReports(),
      this.getAllTrash(),
      this.getAllPhotos(),
      (async () => {
        const t = await tx(["settings"]);
        return promisifyRequest(t.objectStore("settings").getAll());
      })(),
    ]);
    return {
      appName: "Offline Incident & Rescue Report",
      createdBy: "Herman Sade",
      exportedAt: new Date().toISOString(),
      version: DB_VERSION,
      reports,
      trash,
      photos,
      settings: settingsRows,
    };
  },

  async importFullBackup(data, mode = "keep") {
    // mode: "keep" (skip if exists), "replace" (overwrite), "copy" (new id)
    const t = await tx(["reports", "trash", "photos", "settings"], "readwrite");
    const reportsStore = t.objectStore("reports");
    const trashStore = t.objectStore("trash");
    const photosStore = t.objectStore("photos");
    const settingsStore = t.objectStore("settings");

    const handleCollection = async (store, rows, keyField) => {
      for (const row of rows || []) {
        const existing = await promisifyRequest(store.get(row[keyField]));
        if (!existing) {
          store.put(row);
        } else if (mode === "replace") {
          store.put(row);
        } else if (mode === "copy") {
          const clone = { ...row };
          clone[keyField] = row[keyField] + "-copy-" + Date.now();
          store.put(clone);
        }
        // mode === "keep": do nothing, existing wins
      }
    };

    await handleCollection(reportsStore, data.reports, "incidentId");
    await handleCollection(trashStore, data.trash, "incidentId");
    await handleCollection(photosStore, data.photos, "photoId");
    for (const row of data.settings || []) {
      settingsStore.put(row);
    }

    return new Promise((res, rej) => {
      t.oncomplete = () => res();
      t.onerror = () => rej(t.error);
    });
  },
};

window.RescueDB = RescueDB;
